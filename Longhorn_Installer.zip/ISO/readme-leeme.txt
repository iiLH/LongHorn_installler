EN:
This program can handle all the .ISO Of Windows longhorn but you can't boot them. You can made more folders and set them in the var %num% in the main file
ES: 
Este programa puede manejar todas las ISO de Windows Longhorn pero no puedes bootearlas. Puedes crear mas carpetas y usarlas cambiando la variable %num%